# Balance findings — Operation Dead Circuit

Generated 14 August 2026 by `npm run analyse:balance`, which resolves the **entire**
decision space rather than sampling it: 120 formation permutations × 3 total-army
plays × 3 mission pressures × 4 authored branch combinations = **4,320 deterministic
outcomes**, in about a second.

`AGENTS.md` defers enemy AI and faction personality "until the player-side formation
puzzle is proven". This is the first attempt to prove it. Most of the puzzle holds up.
Three things do not.

## What holds

**Placement genuinely decides the outcome.** Extraction counts span the full range
0–4, and win rate by formation order ranges from 2.8% to 44.4% — a 16× spread. The
puzzle is not decorative.

**No order is a universal answer.** Of 120 orders, **zero** always win and **zero**
never win. This is the strongest result in the sweep: it means no player can be handed
"the solution", which is exactly what the design asks for.

**Structure is learnable without being a rule.** The ARMOURED RECOVERY VEHICLE at the
final stop wins 31.5% against 7.1% at the first — a real, discoverable signal. The
ASSAULT WALKER peaks at stop 3 (20.0%). Every other formation sits in a flat
9–16% band across all positions, so only two of the five carry strong positional
pressure. There is a pattern to find, but it does not collapse into a formula.

**Combo chains reward without being mandatory.** Win rate climbs 6.5% → 12.8% → 17.1%
with 0, 1 and 2 chains. Crucially, plans with **no** chain at all still win, so chains
behave as the intended secondary bonus rather than a hidden requirement.

**Authored foresight matters.** Branch combinations range 19.9% (`tempo+clock`) down to
5.6% (`protect+recover`) — a 3.5× spread, which supports the claim that reading the
breakpoints ahead of contact is the core skill.

## What does not hold

### 1. `early-relief` is unwinnable — not hard, impossible

**All 1,440 configurations under this pressure lose.** Best achievable extraction is
**2** against a requirement of 3. Overrun runs 38–128 seconds, against 0–98 on the
other two pressures, so the relief column simply arrives before any plan can finish.

This is a correctness bug, not a difficulty setting. A disclosed mission pressure that
no combination of placements, plays or authored responses can beat is a dead end the
player is invited to walk into. `AGENTS.md` requires a pressure to "alter at least two
strategic levers" so a previous setup "remains understandable but not universally
dominant" — it does not license unwinnable.

**Suggested direction:** the fastest lever is the wave clock. The gap between best
achievable (2) and required (3) is one extraction, and the overrun floor is 38s, so
roughly 40–60 seconds of additional relief delay should make it hard-but-possible.
Re-run the sweep to confirm rather than assuming.

### 2. `spear` (DECISIVE ASSAULT) is a trap option

| Play | Win rate | Best extraction |
|---|---|---|
| `trapline` | 21.1% | 4 |
| `pressure` | 18.1% | 4 |
| `spear` | **1.2%** | **3** |

Excluding the unwinnable pressure, `spear` still manages only 1.8% against 31.7% and
27.1%. It is also the only play that can **never** extract more than 3 — it cannot
produce a decisive result at all, only a bare pass.

Three plays where one wins seventeen times less often is not three approaches; it is
two approaches and a punishment for curiosity. Average overrun tells the story: 67.9s
for `spear` against ~45s for the other two. It is simply too slow for its own clock.

### 3. Mission pressures change difficulty, not strategy

The single best formation order is **identical under all three pressures**, and so are
the second and third:

```
fractured-transit   58.3%   harpoon>furnace>breaker>railjack>hauler
reactor-window      75.0%   harpoon>furnace>breaker>railjack>hauler
early-relief         0.0%   harpoon>furnace>breaker>railjack>hauler
```

`AGENTS.md` asks that a disclosed pressure reshape strategy so "a previously successful
setup remains understandable but not universally dominant". Right now a player who
finds the strongest order once can reuse it forever; the pressure only changes whether
it is enough. The lever moved is difficulty, not the answer.

**Suggested direction:** pressures currently modify timing and role demands. To change
*which* placement is best, at least one pressure needs to alter what a stop rewards —
for example making a stop demand a capability only some formations carry, so the best
answer moves rather than merely getting harder.

## Overall difficulty

The overall win rate is **13.4%**, and this is the first playable mission. Even the
single best order under the most forgiving pressure tops out at 75%. A player
exploring reasonably will lose most attempts on their introduction to the game.

Whether that is correct is a design decision, not a bug — a deliberately punishing
opener is a legitimate choice. But it should be a decision rather than an accident, and
it is worth noting that findings 1 and 2 both inflate it: roughly a third of the
decision space is unwinnable by construction.

## Regression guards

`tests/balance.test.mjs` runs the full sweep and asserts the claims that currently hold
— determinism, that placement changes outcomes, that no order is dominant or hopeless,
that chains help without being mandatory, that branches diverge, and that every play
can win at all. They assert the *shape* of the design, not tuned numbers, so ordinary
balance work will not turn them red.

Deliberately **not** yet asserted: that every mission pressure is winnable. That test
would fail today because of finding 1. Add it once `early-relief` is fixed — it is the
single most valuable guard in this file, and it belongs in the suite the moment it can
pass:

```js
test("every disclosed mission pressure is winnable", () => {
  for (const [pressure, group] of Object.entries(groupBy(rows, (row) => row.pressure))) {
    assert.ok(group.some((row) => row.won), `mission pressure "${pressure}" cannot be won`);
  }
});
```

## Re-running

```powershell
npm.cmd run analyse:balance
```

Run it after any change to formation capabilities, refits, playbook timing, mission
pressure, breakpoint impacts, or enemy plans. It is the cheapest way to find out
whether a tuning change did what you intended across the whole space instead of in the
one configuration you happened to play.
